# Modul Statistika Pilkommedia

Modul ini berisikan data serta fungsi-fungsi yang digunakan untuk keperluan perkuliahan di Program Studi Pendidikan Komputer FKIP ULM Banjarmasin.

Untuk saat ini teradpat satu sub modul, yakni data statistik iwak papuyu dengan beberapa fungsi yang dapat digunakan, yakni sebagai berikut.

- get_data(header=False)
- get_header()
- get_data_by_column(column_name)
- average(column_name)
- median(column_name)
- modes(column_name)
